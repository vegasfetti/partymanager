<?php return array (
  'livewireComponents' => 
  array (
    'app.filament.resources.banner-resource.pages.create-banner' => 'App\\Filament\\Resources\\BannerResource\\Pages\\CreateBanner',
    'app.filament.resources.banner-resource.pages.edit-banner' => 'App\\Filament\\Resources\\BannerResource\\Pages\\EditBanner',
    'app.filament.resources.banner-resource.pages.list-banners' => 'App\\Filament\\Resources\\BannerResource\\Pages\\ListBanners',
    'app.filament.resources.blog-resource.pages.create-blog' => 'App\\Filament\\Resources\\BlogResource\\Pages\\CreateBlog',
    'app.filament.resources.blog-resource.pages.edit-blog' => 'App\\Filament\\Resources\\BlogResource\\Pages\\EditBlog',
    'app.filament.resources.blog-resource.pages.list-blogs' => 'App\\Filament\\Resources\\BlogResource\\Pages\\ListBlogs',
    'app.filament.resources.category-resource.pages.create-category' => 'App\\Filament\\Resources\\CategoryResource\\Pages\\CreateCategory',
    'app.filament.resources.category-resource.pages.edit-category' => 'App\\Filament\\Resources\\CategoryResource\\Pages\\EditCategory',
    'app.filament.resources.category-resource.pages.list-categories' => 'App\\Filament\\Resources\\CategoryResource\\Pages\\ListCategories',
    'app.filament.resources.city-resource.pages.create-city' => 'App\\Filament\\Resources\\CityResource\\Pages\\CreateCity',
    'app.filament.resources.city-resource.pages.edit-city' => 'App\\Filament\\Resources\\CityResource\\Pages\\EditCity',
    'app.filament.resources.city-resource.pages.list-cities' => 'App\\Filament\\Resources\\CityResource\\Pages\\ListCities',
    'app.filament.resources.feedback-resource.pages.create-feedback' => 'App\\Filament\\Resources\\FeedbackResource\\Pages\\CreateFeedback',
    'app.filament.resources.feedback-resource.pages.edit-feedback' => 'App\\Filament\\Resources\\FeedbackResource\\Pages\\EditFeedback',
    'app.filament.resources.feedback-resource.pages.list-feedback' => 'App\\Filament\\Resources\\FeedbackResource\\Pages\\ListFeedback',
    'app.filament.resources.order-resource.pages.create-order' => 'App\\Filament\\Resources\\OrderResource\\Pages\\CreateOrder',
    'app.filament.resources.order-resource.pages.edit-order' => 'App\\Filament\\Resources\\OrderResource\\Pages\\EditOrder',
    'app.filament.resources.order-resource.pages.list-orders' => 'App\\Filament\\Resources\\OrderResource\\Pages\\ListOrders',
    'app.filament.resources.request-resource.pages.create-request' => 'App\\Filament\\Resources\\RequestResource\\Pages\\CreateRequest',
    'app.filament.resources.request-resource.pages.edit-request' => 'App\\Filament\\Resources\\RequestResource\\Pages\\EditRequest',
    'app.filament.resources.request-resource.pages.list-requests' => 'App\\Filament\\Resources\\RequestResource\\Pages\\ListRequests',
    'app.filament.resources.review-resource.pages.create-review' => 'App\\Filament\\Resources\\ReviewResource\\Pages\\CreateReview',
    'app.filament.resources.review-resource.pages.edit-review' => 'App\\Filament\\Resources\\ReviewResource\\Pages\\EditReview',
    'app.filament.resources.review-resource.pages.list-reviews' => 'App\\Filament\\Resources\\ReviewResource\\Pages\\ListReviews',
    'app.filament.resources.service-resource.pages.create-service' => 'App\\Filament\\Resources\\ServiceResource\\Pages\\CreateService',
    'app.filament.resources.service-resource.pages.edit-service' => 'App\\Filament\\Resources\\ServiceResource\\Pages\\EditService',
    'app.filament.resources.service-resource.pages.list-services' => 'App\\Filament\\Resources\\ServiceResource\\Pages\\ListServices',
    'app.filament.resources.smart-order-resource.pages.create-smart-order' => 'App\\Filament\\Resources\\SmartOrderResource\\Pages\\CreateSmartOrder',
    'app.filament.resources.smart-order-resource.pages.edit-smart-order' => 'App\\Filament\\Resources\\SmartOrderResource\\Pages\\EditSmartOrder',
    'app.filament.resources.smart-order-resource.pages.list-smart-orders' => 'App\\Filament\\Resources\\SmartOrderResource\\Pages\\ListSmartOrders',
    'app.filament.resources.smart-order-resource.relation-managers.smart-order-specialists-relation-manager' => 'App\\Filament\\Resources\\SmartOrderResource\\RelationManagers\\SmartOrderSpecialistsRelationManager',
    'app.filament.resources.specialist-resource.pages.create-specialist' => 'App\\Filament\\Resources\\SpecialistResource\\Pages\\CreateSpecialist',
    'app.filament.resources.specialist-resource.pages.edit-specialist' => 'App\\Filament\\Resources\\SpecialistResource\\Pages\\EditSpecialist',
    'app.filament.resources.specialist-resource.pages.list-specialists' => 'App\\Filament\\Resources\\SpecialistResource\\Pages\\ListSpecialists',
    'app.filament.resources.subcategory-resource.pages.create-subcategory' => 'App\\Filament\\Resources\\SubcategoryResource\\Pages\\CreateSubcategory',
    'app.filament.resources.subcategory-resource.pages.edit-subcategory' => 'App\\Filament\\Resources\\SubcategoryResource\\Pages\\EditSubcategory',
    'app.filament.resources.subcategory-resource.pages.list-subcategories' => 'App\\Filament\\Resources\\SubcategoryResource\\Pages\\ListSubcategories',
    'app.filament.resources.user-resource.pages.create-user' => 'App\\Filament\\Resources\\UserResource\\Pages\\CreateUser',
    'app.filament.resources.user-resource.pages.edit-user' => 'App\\Filament\\Resources\\UserResource\\Pages\\EditUser',
    'app.filament.resources.user-resource.pages.list-users' => 'App\\Filament\\Resources\\UserResource\\Pages\\ListUsers',
    'filament.pages.dashboard' => 'Filament\\Pages\\Dashboard',
    'filament.widgets.account-widget' => 'Filament\\Widgets\\AccountWidget',
    'filament.livewire.database-notifications' => 'Filament\\Livewire\\DatabaseNotifications',
    'filament.pages.auth.edit-profile' => 'Filament\\Pages\\Auth\\EditProfile',
    'filament.livewire.global-search' => 'Filament\\Livewire\\GlobalSearch',
    'filament.livewire.notifications' => 'Filament\\Livewire\\Notifications',
    'filament.pages.auth.login' => 'Filament\\Pages\\Auth\\Login',
  ),
  'clusters' => 
  array (
  ),
  'clusteredComponents' => 
  array (
  ),
  'clusterDirectories' => 
  array (
  ),
  'clusterNamespaces' => 
  array (
  ),
  'pages' => 
  array (
    0 => 'Filament\\Pages\\Dashboard',
  ),
  'pageDirectories' => 
  array (
    0 => 'C:\\OSPanel\\domains\\partymanager-three-withkassa\\app\\Filament/Pages',
  ),
  'pageNamespaces' => 
  array (
    0 => 'App\\Filament\\Pages',
  ),
  'resources' => 
  array (
    'C:\\OSPanel\\domains\\partymanager-three-withkassa\\app\\Filament\\Resources\\BannerResource.php' => 'App\\Filament\\Resources\\BannerResource',
    'C:\\OSPanel\\domains\\partymanager-three-withkassa\\app\\Filament\\Resources\\BlogResource.php' => 'App\\Filament\\Resources\\BlogResource',
    'C:\\OSPanel\\domains\\partymanager-three-withkassa\\app\\Filament\\Resources\\CategoryResource.php' => 'App\\Filament\\Resources\\CategoryResource',
    'C:\\OSPanel\\domains\\partymanager-three-withkassa\\app\\Filament\\Resources\\CityResource.php' => 'App\\Filament\\Resources\\CityResource',
    'C:\\OSPanel\\domains\\partymanager-three-withkassa\\app\\Filament\\Resources\\FeedbackResource.php' => 'App\\Filament\\Resources\\FeedbackResource',
    'C:\\OSPanel\\domains\\partymanager-three-withkassa\\app\\Filament\\Resources\\OrderResource.php' => 'App\\Filament\\Resources\\OrderResource',
    'C:\\OSPanel\\domains\\partymanager-three-withkassa\\app\\Filament\\Resources\\RequestResource.php' => 'App\\Filament\\Resources\\RequestResource',
    'C:\\OSPanel\\domains\\partymanager-three-withkassa\\app\\Filament\\Resources\\ReviewResource.php' => 'App\\Filament\\Resources\\ReviewResource',
    'C:\\OSPanel\\domains\\partymanager-three-withkassa\\app\\Filament\\Resources\\ServiceResource.php' => 'App\\Filament\\Resources\\ServiceResource',
    'C:\\OSPanel\\domains\\partymanager-three-withkassa\\app\\Filament\\Resources\\SmartOrderResource.php' => 'App\\Filament\\Resources\\SmartOrderResource',
    'C:\\OSPanel\\domains\\partymanager-three-withkassa\\app\\Filament\\Resources\\SpecialistResource.php' => 'App\\Filament\\Resources\\SpecialistResource',
    'C:\\OSPanel\\domains\\partymanager-three-withkassa\\app\\Filament\\Resources\\SubcategoryResource.php' => 'App\\Filament\\Resources\\SubcategoryResource',
    'C:\\OSPanel\\domains\\partymanager-three-withkassa\\app\\Filament\\Resources\\UserResource.php' => 'App\\Filament\\Resources\\UserResource',
  ),
  'resourceDirectories' => 
  array (
    0 => 'C:\\OSPanel\\domains\\partymanager-three-withkassa\\app\\Filament/Resources',
  ),
  'resourceNamespaces' => 
  array (
    0 => 'App\\Filament\\Resources',
  ),
  'widgets' => 
  array (
    0 => 'Filament\\Widgets\\AccountWidget',
  ),
  'widgetDirectories' => 
  array (
    0 => 'C:\\OSPanel\\domains\\partymanager-three-withkassa\\app\\Filament/Widgets',
  ),
  'widgetNamespaces' => 
  array (
    0 => 'App\\Filament\\Widgets',
  ),
);