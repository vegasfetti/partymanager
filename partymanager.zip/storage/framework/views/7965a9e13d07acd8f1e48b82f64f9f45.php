<?php $__env->startSection('title', 'Блог | ПАТИМЕНЕДЖЕР'); ?>
<?php $__env->startSection('description', 'Читайте статьи, новости и полезную информацию на сайте ПАТИМЕНЕДЖЕР.'); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('particals.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>










    <!-- blog -->
    <main class="container mx-auto px-4">
        <!-- title -->
        <div class="big-title pb-10 pt-20 text-center">
            <h2 class="font-semibold text-3xl sm:text-4xl">Наш блог</h2>
            <p class="opacity-50 text-sm sm:text-base">Интересно почитать на досуге</p>
        </div>

        <!-- большие блоги -->
        <div class="big_blogs grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 gap-6 md:gap-10 mb-20">
            <?php $__currentLoopData = $blogs->take(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('blog.show', $blog->slug)); ?>"
                    class="big_blog__item flex flex-col gap-2.5">
                    <img src="<?php echo e(asset("storage/" . $blog->image)); ?>" alt="<?php echo e($blog->title); ?>"
                        class="blog__item--img w-full h-[425px] w-full rounded-2xl shadow-md object-cover object-center">
                    <p class="blog__item--title font-semibold text-lg sm:text-xl"><?php echo e($blog->title); ?></p>
                    <p class="blog__item--subtitle opacity-50 text-sm sm:text-base"><?php echo e($blog->subtitle); ?></p>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <!-- обычные блоги -->
        <div class="blogs grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 md:gap-10 mb-20">
            <?php $__currentLoopData = $blogs->slice(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('blog.show', $blog->slug)); ?>" class="blog__item flex flex-col gap-2.5">
                    <img src="<?php echo e(asset("storage/" . $blog->image)); ?>" alt="<?php echo e($blog->title); ?>"
                        class="blog__item--img w-full h-[250px] rounded-2xl shadow object-center object-cover">
                    <p class="blog__item--title font-semibold text-lg sm:text-lg"><?php echo e($blog->title); ?></p>
                    <p class="blog__item--subtitle opacity-50 text-sm sm:text-sm"><?php echo e($blog->subtitle); ?></p>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </main>
    <?php echo $__env->make('particals.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\partymanager-three-withkassa\resources\views\pages\blog\index.blade.php ENDPATH**/ ?>