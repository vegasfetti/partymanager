
                



<?php if($paginator->hasPages()): ?>
    <nav role="navigation" aria-label="Pagination Navigation"
        class="flex items-center justify-center space-x-1 font-semibold">

        
        <?php if($paginator->onFirstPage()): ?>
            <span class="px-3 py-1 border border-gray-300 rounded-lg text-gray-400">‹</span>
        <?php else: ?>
            <a href="<?php echo e($paginator->previousPageUrl()); ?>"
                class="px-3 py-1 border border-gray-300 rounded-lg text-[#1b1e4a] hover:bg-[#1b1e4a] hover:border-[#1b1e4a] hover:text-white hover: transition">‹</a>
        <?php endif; ?>

        
        <?php if($paginator->currentPage() > 3): ?>
            <a href="<?php echo e($paginator->url(1)); ?>"
                class="px-3 py-1 border border-gray-300 rounded-lg text-[#1b1e4a] hover:bg-[#1b1e4a] hover:border-[#1b1e4a] hover:text-white transition">1</a>
        <?php endif; ?>

        
        <?php if($paginator->currentPage() > 4): ?>
            <span class="px-3 py-1">...</span>
        <?php endif; ?>

        
        <?php $__currentLoopData = range(max(1, $paginator->currentPage() - 1), min($paginator->lastPage(), $paginator->currentPage() + 1)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($page == $paginator->currentPage()): ?>
                <span class="px-3 py-1 border border-[#1b1e4a] rounded-lg bg-[#1b1e4a] text-white"><?php echo e($page); ?></span>
            <?php else: ?>
                <a href="<?php echo e($paginator->url($page)); ?>"
                    class="px-3 py-1 border border-gray-300 rounded-lg text-[#1b1e4a] hover:bg-[#1b1e4a] hover:border-[#1b1e4a] hover:text-white transition"><?php echo e($page); ?></a>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
        <?php if($paginator->currentPage() < $paginator->lastPage() - 3): ?>
            <span class="px-3 py-1">...</span>
        <?php endif; ?>

        
        <?php if($paginator->currentPage() < $paginator->lastPage() - 2): ?>
            <a href="<?php echo e($paginator->url($paginator->lastPage())); ?>"
                class="px-3 py-1 border border-gray-300 rounded-lg text-[#1b1e4a] hover:bg-[#1b1e4a] hover:border-[#1b1e4a] hover:text-white transition"><?php echo e($paginator->lastPage()); ?></a>
        <?php endif; ?>

        
        <?php if($paginator->hasMorePages()): ?>
            <a href="<?php echo e($paginator->nextPageUrl()); ?>"
                class="px-3 py-1 border border-gray-300 rounded-lg text-[#1b1e4a] hover:bg-[#1b1e4a] hover:border-[#1b1e4a] hover:text-white transition">›</a>
        <?php else: ?>
            <span class="px-3 py-1 border border-gray-300 rounded-lg text-gray-400">›</span>
        <?php endif; ?>
    </nav>
<?php endif; ?>


<script>
</script><?php /**PATH C:\OSPanel\domains\partymanager-three-withkassa\resources\views\vendor\pagination\tailwind.blade.php ENDPATH**/ ?>