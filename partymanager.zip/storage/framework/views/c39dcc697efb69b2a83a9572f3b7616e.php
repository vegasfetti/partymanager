<?php $__env->startComponent('mail::message'); ?>
# Вам пришла заявка на бронирование

Здравствуйте, <?php echo e($order->specialist->user->name ?? 'Исполнитель'); ?>!  
Вам пришла новая заявка на бронирование.

**От:** <?php echo e($order->user->name ?? 'Неизвестный пользователь'); ?>  <br>
**Телефон:** <?php echo e($order->phone); ?>  <br>
<?php if($order->comment): ?>
**Комментарий:** <?php echo e($order->comment); ?><br>
<?php endif; ?>
**Дата отправки:** <?php echo e($order->created_at ->format('d.m.Y H:i')); ?><br>

<?php $__env->startComponent('mail::button', ['url' => route('profile')]); ?>
Посмотреть заявку
<?php echo $__env->renderComponent(); ?>

С уважением,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\OSPanel\domains\partymanager-three-withkassa\resources\views\emails\orders\booked.blade.php ENDPATH**/ ?>