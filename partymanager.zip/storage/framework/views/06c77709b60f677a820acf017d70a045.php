<?php $__env->startSection('title', 'Все исполнители | ПАТИМЕНЕДЖЕР'); ?>
<?php $__env->startSection('description', 'Найдите лучших специалистов для вашего праздника в одном месте. Удобный поиск, фильтры по категориям, быстрый просмотр портфолио и отзывов. ПАТИМЕНЕДЖЕР — ваш надежный помощник в поиске исполнителей.'); ?>



<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('particals.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php $__env->startPush('app-links'); ?>
        <!-- nouislider -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/noUiSlider/15.7.1/nouislider.min.css" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/noUiSlider/15.7.1/nouislider.min.js"></script>
    <?php $__env->stopPush(); ?>


    <main class="container">

        <!-- breadcrumbs -->
        <div class="breadcrumbs flex flex-wrap gap-3.5 pt-10 pb-5">
            <a class="opacity-50" href="<?php echo e(route('main')); ?>">Главная</a>
            <img src="<?php echo e(asset('ico/breadcrumbs.svg')); ?>" alt="">

            <a class="<?php echo e(isset($activeCategory) ? 'opacity-50' : ''); ?>" href="<?php echo e(route('specialists')); ?>">Специалисты</a>

            <?php if(isset($activeCategory)): ?>
                <img src="<?php echo e(asset('ico/breadcrumbs.svg')); ?>" alt="">
                <a class="<?php echo e(isset($activeSubcategory) ? 'opacity-50' : ''); ?>"
                    href="<?php echo e(route('specialists.byCategory', $activeCategory->slug)); ?>">
                    <?php echo e($activeCategory->name); ?>

                </a>
            <?php endif; ?>

            <?php if(isset($activeSubcategory)): ?>
                <img src="<?php echo e(asset('ico/breadcrumbs.svg')); ?>" alt="">
                <a href="<?php echo e(route('specialists.bySubcategory', [$activeCategory->slug, $activeSubcategory->slug])); ?>">
                    <?php echo e($activeSubcategory->name); ?>

                </a>
            <?php endif; ?>
        </div>




        <button id="openFilter"
            class="bg-[#FFD700] fixed top-1/2 left-0 transform translate-y-1/2 rounded-[0px_10px_10px_0px] flex items-center gap-5 px-4 py-2 border border-[#0000001a] font-semibold text-[#1B1E4A] cursor-pointer">
            <p>Открыть фильтр</p>
            <img src="<?php echo e(asset('ico/filter.png')); ?>" alt="">
        </button>


        <div id="filterOverlay" class="filter-overlay hidden"></div>
        
        <div id="filterModal" class="specialists__filtration__adaptive">
            <button id="closeFilter" class=" opacity-50 hover:opacity-100 cursor-pointer absolute top-5 right-5">
                <img class="p-3" alt="" src="<?php echo e(asset('ico/close.png')); ?>">
            </button>
            <div class="flex flex-col col-span-2 gap-5 mb-5 specialists__filtration__adaptive--container pt-2 relative">

                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="specialists__filtration--el flex flex-col gap-2.5">

                        
                        <a class="text-lg font-medium <?php echo e(isset($activeCategory) && $activeCategory->id == $category->id ? 'opacity-100' : 'opacity-50 hover:opacity-100'); ?>"
                            href="<?php echo e(route('specialists.byCategory', ['category' => $category->slug])); ?>">
                            <?php echo e($category->name); ?>

                        </a>

                        
                        <?php if(isset($activeCategory) && $activeCategory->id == $category->id): ?>
                            <?php $__currentLoopData = $category->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="opacity-50 hover:opacity-100 w-fit
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            <?php echo e(isset($activeSubcategory) && $activeSubcategory->id == $subcategory->id ? 'opacity-100' : ''); ?>"
                                    href="<?php echo e(route('specialists.bySubcategory', ['category' => $category->slug, 'subcategory' => $subcategory->slug])); ?>">
                                    – <?php echo e($subcategory->name); ?>

                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <div class="w-full h-[1px] bg-[#0000001a]"></div>

                <form class="flex flex-col gap-5" method="get" class="w-full" action="<?php echo e(url()->current()); ?>">


                    <!-- select -->
                    <div class="relative w-full flex flex-col gap-2.5">
                        <label class="font-semibold text-gray-400 text-md" for="sort">Сортировать:</label>
                        <div class="relative flex items-center">
                            <select name="sort" id="sort"
                                class="appearance-none w-full px-4 py-3 border border-gray-300 rounded-xl bg-[#f0f4fa] text-gray-500 focus:outline-[#FFD700]">
                                <option class="text-lg" value="default" <?php echo e(!$sort ? 'selected' : ''); ?>>По умолчанию</option>
                                <option class="text-lg" value="popularity" <?php echo e($sort == 'popularity' ? 'selected' : ''); ?>>По
                                    популярности</option>
                                <option class="text-lg" value="rating" <?php echo e($sort == 'rating' ? 'selected' : ''); ?>>По рейтингу
                                </option>
                                <option class="text-lg" value="price" <?php echo e($sort == 'price' ? 'selected' : ''); ?>>По цене
                                </option>
                            </select>


                            <!-- Иконка стрелки, центрируемая через top-1/2 и -translate-y-1/2 -->
                            <div
                                class="absolute flex items-center transform -translate-y-1/2 pointer-events-none top-1/2 right-3">
                                <svg class="w-5 h-5 opacity-50" fill="none" stroke="currentColor" stroke-width="2"
                                    viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
                                </svg>
                            </div>
                        </div>
                    </div>


                    <!-- range -->
                    <div class="w-full nouislider-container">
                        <div class="mb-5" id="nouislider"></div>

                        <div class="grid grid-cols-2 gap-4">






                            <div class="w-full flex flex-col gap-2.5">
                                <label class="font-semibold text-gray-400 text-md" for="priceFromFormatted">Цена
                                    от:</label>
                                <input type="text" id="priceFromFormatted" placeholder="Цена от:"
                                    value="<?php echo e(number_format($minPrice, 0, '.', ' ')); ?>"
                                    class="text-[#1B1E4A] font-medium w-full px-4 py-3 border border-gray-300 rounded-xl bg-[#f0f4fa] focus:!border-gray-300">
                                <input type="hidden" id="priceFrom" name="min_price" value="<?php echo e($minPrice); ?>">
                            </div>
                            <div class="w-full flex flex-col gap-2.5">
                                <label class="font-semibold text-gray-400 text-md" for="priceToFormatted">Цена
                                    до:</label>
                                <input type="text" id="priceToFormatted" placeholder="Цена до:"
                                    value="<?php echo e(number_format($maxPrice, 0, '.', ' ')); ?>"
                                    class="text-[#1B1E4A] font-medium w-full px-4 py-3 border border-gray-300 rounded-xl bg-[#f0f4fa] focus:!border-gray-300">
                                <input type="hidden" id="priceTo" name="max_price" value="<?php echo e($maxPrice); ?>">
                            </div>
                        </div>

                    </div>

                    <!-- select -->
                    <div class="relative w-full flex flex-col gap-2.5">
                        <label class="font-semibold text-gray-400 text-md" for="experience">Опыт работы:</label>
                        <div class="relative flex items-center">
                            <select id="experience" name="experience"
                                class="appearance-none w-full px-4 py-3 border border-gray-300 rounded-xl bg-[#f0f4fa] text-gray-500 focus:outline-[#FFD700]">
                                <option class="text-lg" value="default" class="" <?php echo e(!$exp ? 'selected disabled' : ''); ?>>Не
                                    важно</option>
                                <option class="text-lg" value="less_than_1" <?php echo e($exp == 'less_than_1' ? 'selected' : ''); ?>

                                    class="">Менее
                                    1
                                    года
                                </option>
                                <option class="text-lg" value="1_3_years" <?php echo e($exp == '1_3_years' ? 'selected' : ''); ?>

                                    class="">От
                                    1 до 3
                                    лет
                                </option>
                                <option class="text-lg" value="3_5_years" <?php echo e($exp == '3_5_years' ? 'selected' : ''); ?>

                                    class="">От
                                    3 до 5
                                    лет
                                </option>
                                <option class="text-lg" value="more_than_5" <?php echo e($exp == 'more_than_5' ? 'selected' : ''); ?>

                                    class="">Более
                                    5 лет
                                </option>
                            </select>
                            <!-- Иконка стрелки, центрируемая через top-1/2 и -translate-y-1/2 -->
                            <div
                                class="absolute flex items-center transform -translate-y-1/2 pointer-events-none top-1/2 right-3">
                                <svg class="w-5 h-5 opacity-50" fill="none" stroke="currentColor" stroke-width="2"
                                    viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
                                </svg>
                            </div>
                        </div>
                    </div>


                    <!-- select -->
                    <div class="relative w-full flex flex-col gap-2.5">
                        <label class="font-semibold text-gray-400 text-md" for="subject_type">Вид занятости</label>
                        <div class="relative flex items-center">
                            <select name="subject_type" id="subject_type"
                                class="appearance-none w-full px-4 py-3 border border-gray-300 rounded-xl bg-[#f0f4fa] text-gray-500 focus:outline-[#FFD700]">
                                <option class="text-lg" value="default" <?php echo e(!$subject_type ? 'selected disabled' : ''); ?>>
                                    Любой</option>
                                <option class="text-lg" value="individual" <?php echo e($subject_type == 'individual' ? 'selected' : ''); ?>>
                                    Частное лицо
                                </option>
                                <option class="text-lg" value="company" <?php echo e($subject_type == 'company' ? 'selected' : ''); ?>>
                                    Компания
                                </option>
                            </select>
                            <!-- Иконка стрелки, центрируемая через top-1/2 и -translate-y-1/2 -->
                            <div
                                class="absolute flex items-center transform -translate-y-1/2 pointer-events-none top-1/2 right-3">
                                <svg class="w-5 h-5 opacity-50" fill="none" stroke="currentColor" stroke-width="2"
                                    viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
                                </svg>
                            </div>
                        </div>
                    </div>

                    <label class="inline-flex items-center gap-2 cursor-pointer">
                        <input <?php echo e(request()->has('contract') ? 'checked' : ''); ?> type="checkbox" class="hidden peer"
                            name="contract" />

                        <div
                            class="w-5 h-5 rounded-sm border border-gray-300 bg-[#f0f4fa] peer-checked:bg-[#FFD700] peer-checked:border-[#0000001a] transition-all duration-200">
                        </div>

                        <span class="text-md font-medium text-[#1B1E4A] ">Только по договору</span>
                    </label>

                    <label class="inline-flex items-center gap-2 cursor-pointer">
                        <input <?php echo e(request()->has('verified') ? 'checked' : ''); ?> type="checkbox" class="hidden peer"
                            name="verified" />

                        <div
                            class="w-5 h-5 rounded-sm border border-gray-300 bg-[#f0f4fa] peer-checked:bg-[#FFD700] peer-checked:border-[#0000001a] transition-all duration-200">
                        </div>

                        <span class="text-md font-medium text-[#1B1E4A]">Исполнитель проверен</span>
                    </label>

                    <label class="inline-flex items-center gap-2 cursor-pointer">
                        <input <?php echo e(request()->has('filled') ? 'checked' : ''); ?> type="checkbox" class="hidden peer"
                            name="filled" />

                        <div
                            class="w-5 h-5 rounded-sm border border-gray-300 bg-[#f0f4fa] peer-checked:bg-[#FFD700] peer-checked:border-[#0000001a] transition-all duration-200">
                        </div>

                        <span class="text-md font-medium text-[#1B1E4A]">Заполненный профиль</span>
                    </label>

                    <button
                        class="bg-[#FFD700] px-4 py-3 rounded-xl border border-[#0000001a] font-semibold text-[#1B1E4A] cursor-pointer">Применить</button>
                </form>

            </div>
        </div>





        <!-- specialists -->

        <div class="grid grid-cols-4 gap-5 specialists">
            <div class="flex flex-col col-span-1 gap-5 mb-20 specialists__filtration">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="specialists__filtration--el flex flex-col gap-2.5">

                        
                        <a class="text-lg font-medium <?php echo e(isset($activeCategory) && $activeCategory->id == $category->id ? 'opacity-100' : 'opacity-50 hover:opacity-100'); ?>"
                            href="<?php echo e(route('specialists.byCategory', ['category' => $category->slug])); ?>">
                            <?php echo e($category->name); ?>

                        </a>

                        
                        <?php if(isset($activeCategory) && $activeCategory->id == $category->id): ?>
                            <?php $__currentLoopData = $category->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="opacity-50 hover:opacity-100 w-fit
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            <?php echo e(isset($activeSubcategory) && $activeSubcategory->id == $subcategory->id ? 'opacity-100' : ''); ?>"
                                    href="<?php echo e(route('specialists.bySubcategory', ['category' => $category->slug, 'subcategory' => $subcategory->slug])); ?>">
                                    – <?php echo e($subcategory->name); ?>

                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <div class="w-full h-[1px] bg-[#0000001a]"></div>

                <form class="flex flex-col gap-5" method="get" class="w-full" action="<?php echo e(url()->current()); ?>">


                    <!-- select -->
                    <div class="relative w-full flex flex-col gap-2.5">
                        <label class="font-semibold text-gray-400 text-md" for="sort">Сортировать:</label>
                        <div class="relative flex items-center">
                            <select name="sort" id="sort"
                                class="appearance-none w-full px-4 py-3 border border-gray-300 rounded-xl bg-[#f0f4fa] text-gray-500 focus:outline-[#FFD700]">
                                <option class="text-lg" value="default" <?php echo e(!$sort ? 'selected' : ''); ?>>По умолчанию</option>
                                <option class="text-lg" value="popularity" <?php echo e($sort == 'popularity' ? 'selected' : ''); ?>>По
                                    популярности</option>
                                <option class="text-lg" value="rating" <?php echo e($sort == 'rating' ? 'selected' : ''); ?>>По рейтингу
                                </option>
                                <option class="text-lg" value="price" <?php echo e($sort == 'price' ? 'selected' : ''); ?>>По цене
                                </option>
                            </select>

                            <!-- Иконка стрелки, центрируемая через top-1/2 и -translate-y-1/2 -->
                            <div
                                class="absolute flex items-center transform -translate-y-1/2 pointer-events-none top-1/2 right-3">
                                <svg class="w-5 h-5 opacity-50" fill="none" stroke="currentColor" stroke-width="2"
                                    viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
                                </svg>
                            </div>
                        </div>
                    </div>


                    <!-- range -->
                    <div class="w-full nouislider-container">
                        <div class="mb-5" id="nouislider"></div>

                        <div class="grid grid-cols-2 gap-4">






                            <div class="w-full flex flex-col gap-2.5">
                                <label class="font-semibold text-gray-400 text-md" for="priceFromFormatted">Цена
                                    от:</label>
                                <input type="text" id="priceFromFormatted" placeholder="Цена от:"
                                    value="<?php echo e(number_format($minPrice, 0, '.', ' ')); ?>"
                                    class="text-[#1B1E4A] font-medium w-full px-4 py-3 border border-gray-300 rounded-xl bg-[#f0f4fa] focus:!border-gray-300">
                                <input type="hidden" id="priceFrom" name="min_price" value="<?php echo e($minPrice); ?>">
                            </div>
                            <div class="w-full flex flex-col gap-2.5">
                                <label class="font-semibold text-gray-400 text-md" for="priceToFormatted">Цена
                                    до:</label>
                                <input type="text" id="priceToFormatted" placeholder="Цена до:"
                                    value="<?php echo e(number_format($maxPrice, 0, '.', ' ')); ?>"
                                    class="text-[#1B1E4A] font-medium w-full px-4 py-3 border border-gray-300 rounded-xl bg-[#f0f4fa] focus:!border-gray-300">
                                <input type="hidden" id="priceTo" name="max_price" value="<?php echo e($maxPrice); ?>">
                            </div>
                        </div>

                    </div>



                    <!-- select -->
                    <div class="relative w-full flex flex-col gap-2.5">
                        <label class="font-semibold text-gray-400 text-md" for="experience">Опыт работы:</label>
                        <div class="relative flex items-center">
                            <select id="experience" name="experience"
                                class="appearance-none w-full px-4 py-3 border border-gray-300 rounded-xl bg-[#f0f4fa] text-gray-500 focus:outline-[#FFD700]">
                                <option class="text-lg" value="default" class="" <?php echo e(!$exp ? 'selected disabled' : ''); ?>>Не
                                    важно</option>
                                <option class="text-lg" value="less_than_1" <?php echo e($exp == 'less_than_1' ? 'selected' : ''); ?>

                                    class="">Менее
                                    1
                                    года
                                </option>
                                <option class="text-lg" value="1_3_years" <?php echo e($exp == '1_3_years' ? 'selected' : ''); ?>

                                    class="">От 1 до 3
                                    лет
                                </option>
                                <option class="text-lg" value="3_5_years" <?php echo e($exp == '3_5_years' ? 'selected' : ''); ?>

                                    class="">От 3 до 5
                                    лет
                                </option>
                                <option class="text-lg" value="more_than_5" <?php echo e($exp == 'more_than_5' ? 'selected' : ''); ?>

                                    class="">Более
                                    5 лет
                                </option>
                            </select>
                            <!-- Иконка стрелки, центрируемая через top-1/2 и -translate-y-1/2 -->
                            <div
                                class="absolute flex items-center transform -translate-y-1/2 pointer-events-none top-1/2 right-3">
                                <svg class="w-5 h-5 opacity-50" fill="none" stroke="currentColor" stroke-width="2"
                                    viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
                                </svg>
                            </div>
                        </div>
                    </div>


                    <!-- select -->
                    <div class="relative w-full flex flex-col gap-2.5">
                        <label class="font-semibold text-gray-400 text-md" for="subject_type">Вид занятости</label>
                        <div class="relative flex items-center">
                            <select name="subject_type" id="subject_type"
                                class="appearance-none w-full px-4 py-3 border border-gray-300 rounded-xl bg-[#f0f4fa] text-gray-500 focus:outline-[#FFD700]">
                                <option class="text-lg" value="default" class="" <?php echo e(!$subject_type ? 'selected disabled' : ''); ?>>Любой
                                </option>
                                <option class="text-lg" value="individual" <?php echo e($subject_type == 'individual' ? 'selected' : ''); ?> class="">
                                    Частное
                                    лицо</option>
                                <option class="text-lg" value=" company" <?php echo e($subject_type == 'company' ? 'selected' : ''); ?>

                                    class="">
                                    Компания
                                </option>

                            </select>
                            <!-- Иконка стрелки, центрируемая через top-1/2 и -translate-y-1/2 -->
                            <div
                                class="absolute flex items-center transform -translate-y-1/2 pointer-events-none top-1/2 right-3">
                                <svg class="w-5 h-5 opacity-50" fill="none" stroke="currentColor" stroke-width="2"
                                    viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
                                </svg>
                            </div>
                        </div>
                    </div>

                    <label class="inline-flex items-center gap-2 cursor-pointer">
                        <input <?php echo e(request()->has('contract') ? 'checked' : ''); ?> type="checkbox" class="hidden peer"
                            name="contract" />

                        <div
                            class="w-5 h-5 rounded-sm border border-gray-300 bg-[#f0f4fa] peer-checked:bg-[#FFD700] peer-checked:border-[#0000001a] transition-all duration-200">
                        </div>

                        <span class="text-md font-medium text-[#1B1E4A] ">Только по договору</span>
                    </label>

                    <label class="inline-flex items-center gap-2 cursor-pointer">
                        <input <?php echo e(request()->has('verified') ? 'checked' : ''); ?> type="checkbox" class="hidden peer"
                            name="verified" />

                        <div
                            class="w-5 h-5 rounded-sm border border-gray-300 bg-[#f0f4fa] peer-checked:bg-[#FFD700] peer-checked:border-[#0000001a] transition-all duration-200">
                        </div>

                        <span class="text-md font-medium text-[#1B1E4A]">Исполнитель проверен</span>
                    </label>

                    <label class="inline-flex items-center gap-2 cursor-pointer">
                        <input <?php echo e(request()->has('filled') ? 'checked' : ''); ?> type="checkbox" class="hidden peer"
                            name="filled" />

                        <div
                            class="w-5 h-5 rounded-sm border border-gray-300 bg-[#f0f4fa] peer-checked:bg-[#FFD700] peer-checked:border-[#0000001a] transition-all duration-200">
                        </div>

                        <span class="text-md font-medium text-[#1B1E4A]">Заполненный профиль</span>
                    </label>

                    <button
                        class="bg-[#FFD700] px-4 py-3 rounded-xl border border-[#0000001a] font-semibold text-[#1B1E4A] cursor-pointer">Применить</button>
                </form>

            </div>




            <div class="w-full col-span-3 specialists__list">

                <!-- swiper -->
                <div class="swiper specSwiper h-[300px] rounded-2xl">
                    <div class="swiper-wrapper ">
                        <!-- slider -->

                        <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="relative swiper-slide">
                                <div class="absolute inset-0 bg-black opacity-50 slide__promo rounded-2xl"></div>

                                <img class="object-cover object-center w-full h-full rounded-2xl"
                                    src="<?php echo e(asset('storage/' . $banner->image)); ?>" alt="<?php echo e($banner->title); ?>">
                                <div class="slide-text text-right absolute bottom-[25px] right-[25px] text-[#F5F9FF]">
                                    <?php if($banner->is_promo == 1): ?>
                                        <div
                                            class="slide-text__promo text-xs opacity-30 hover:opacity-100 pt-1 pb-1 pl-2 pr-2 rounded-sm bg-[#F5F9FF] text-black inline-block mb-2.5">
                                            промо</div>
                                    <?php endif; ?>
                                    <div class="text-2xl font-bold slide-text__title"><?php echo e($banner->title); ?></div>
                                    <div class="text-lg font-light slide-text__subtitle"><?php echo e($banner->subtitle); ?></div>
                                    <a href="<?php echo e($banner->link); ?>"
                                        class="slide-text__btn pt-2 pb-2 pl-4 pr-4 rounded bg-[#F5F9FF] text-black inline-block mt-5 font-medium">перейти</a>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




                    </div>

                    <div class="swiper-scrollbar"></div>

                </div>

                <!-- search -->
                <form
                    class="banner-search flex my-5 bg-[#F5F9FF] p-2.5 rounded-xl w-full justify-between gap-2.5 border border-[#0000001a]"
                    action="<?php echo e(url()->current()); ?>" method="get">
                    <div class="flex items-center w-full gap-2">
                        <img class="pl-2.5 pr-2.5" src="<?php echo e(asset('ico/search.png')); ?>" alt="поиск">
                        <input id="search" class="w-full outline-none" type="text" name="search"
                            value="<?php echo e(old('search', $search)); ?>" placeholder="Поиск специалистов">
                    </div>
                    <button
                        class="bg-[#FFD700] px-4 py-2 rounded-lg cursor-pointer font-medium border border-[#0000001a]">поиск</button>
                </form>



                <?php if(count($specialists) == 0): ?>
                    <!-- title -->
                    <div class="mt-20 mb-8 big-title">
                        <h2 class="font-semibold text-4xl text-[#000]">На данный момент нет подходящих специалистов</h2>
                        <p class="text-[#000] opacity-50">Попробуйте поменять фильтрацию или попробуйте позже</p>
                    </div>

                    <a class="text-[#000] font-medium px-4 py-2 rounded-lg border border-[#0000001a]"
                        href="<?php echo e(route('specialists')); ?>">Сбросить</a>
                <?php endif; ?>






                <!-- cards -->
                <div class="flex flex-col gap-5 specialists__list__cards mb-15">
                    <?php $__currentLoopData = $specialists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specialist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
$view = App\Models\Visit::where('specialist_id', $specialist->id)
        ->where('user_id', auth()->id())
        ->where('updated_at', '>=', now()->subDay())
        ->first();                        
        ?>
                        <div
                            class="relative specialists__card p-4 sm:p-5 lg:p-6 rounded-2xl border <?php echo e($specialist->promoted_until >= \Carbon\Carbon::now() ? 'border-[#ffd9006e]' : 'border-[#0000001a]'); ?>  grid grid-cols-1 sm:grid-cols-5 lg:grid-cols-4 gap-5 relative">


                            <?php if($view): ?>
                                <p class="absolute opacity-50 text-sm top-2 right-2 py-1 px-2.5 rounded-lg bg-[#f0f4fa] border border-[#0000001a] z-50">просмотренно</p>
                            <?php endif; ?>
                            <!-- Фото -->
                            <div class="w-full h-full sm:col-span-2 lg:col-span-1 specialists__card__img order-1 lg:order-none">
                                <div class="mb-4 lg:mb-5 card-slider-container">
                                    <a href="<?php echo e(route('specialists.show', $specialist->id)); ?>"
                                        style="--swiper-navigation-color: #fff; --swiper-pagination-color: #fff"
                                        class="relative swiper card-swiper2 rounded-xl">
                                        <div class="swiper-wrapper">
                                            <?php $__currentLoopData = $specialist->specImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="swiper-slide">
                                                    <img class="w-full aspect-square object-cover object-center rounded-2xl"
                                                        src="<?php echo e(asset('storage/' . $img->image)); ?>" alt="Фото" />
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </a>

                                    <div thumbsSlider="" class="swiper card-swiper mt-2.5">
                                        <div class="rounded swiper-wrapper">
                                            <?php $__currentLoopData = $specialist->specImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="swiper-slide">
                                                    <img class="w-full aspect-square object-cover object-center rounded-2xl"
                                                        src="<?php echo e(asset('storage/' . $img->image)); ?>" alt="Фото" />
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>

                                <!-- Автор -->
                                <a href="<?php echo e(route('specialists') . '?search=' . $specialist->user->name); ?>"
                                    class="specialists__card__author flex gap-2 items-center">
                                    <img src="<?php echo e(asset('storage/' . $specialist->user->image)); ?>" alt=""
                                        class="w-10 h-10 sm:w-12 sm:h-12 rounded-full object-cover">
                                    <div>
                                        <p class="text-sm sm:text-md font-semibold max-w-[150px] truncate">
                                            <?php echo e($specialist->user->name); ?>

                                        </p>
                                        <?php if($specialist->reviews_avg_rating): ?>
                                            <div class="flex gap-1.5 items-center text-sm sm:text-sm opacity-70">
                                                <img src="<?php echo e(asset('ico/star.svg')); ?>" alt="" class="w-3.5 h-3.5 sm:w-4 sm:h-4">
                                                <p><?php echo e(number_format($specialist->reviews_avg_rating ?? 0, 1)); ?></p>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </a>
                            </div>

                            <!-- Информация -->
                            <div class="sm:col-span-3 lg:col-span-3 specialists__card__info order-2 lg:order-none">
                                <div class="font-semibold text-base sm:text-lg xl:text-xl mb-2 line-clamp-1">
                                    <a href="<?php echo e(route('specialists.show', $specialist->id)); ?>"><?php echo e($specialist->title); ?></a>
                                </div>

                                <div class="mb-4 text-sm sm:text-base opacity-75 line-clamp-3">
                                    <a
                                        href="<?php echo e(route('specialists.show', $specialist->id)); ?>"><?php echo nl2br(e($specialist->description)); ?></a>
                                </div>

                                <div class="flex flex-wrap gap-x-2 gap-y-1 text-sm sm:text-sm lg:text-base opacity-50">
                                    <p><?php echo e($specialist->getSubjectTypeLabel()); ?></p>
                                    <p>•</p>
                                    <p>Работа по договору: <?php echo e($specialist->getIsContractLabel()); ?></p>
                                    <p>•</p>
                                    <p>Опыт: <?php echo e($specialist->getExperienceLabel()); ?></p>
                                </div>

                                <!-- Контакты -->
                                <a href="<?php echo e(route('specialists.show', $specialist->id)); ?>"
                                    class="flex flex-wrap gap-y-2.5 my-4">
                                    <div class="flex gap-2 items-center opacity-50 w-full sm:w-1/2">
                                        <img src="<?php echo e(asset('ico/location.png')); ?>" alt="" class="w-4 h-4 object-contain">
                                        <p class="truncate"><?php echo e($specialist->city->name); ?></p>
                                    </div>
                                    <?php if($specialist->website): ?>
                                        <div class="flex gap-2 items-center opacity-50 w-full sm:w-1/2">
                                            <img src="<?php echo e(asset('ico/browser.png')); ?>" alt="" class="w-4 h-4 object-contain">
                                            <p class="truncate"><?php echo e($specialist->website); ?></p>
                                        </div>
                                    <?php endif; ?>
                                    <?php if($specialist->phone): ?>
                                        <div class="flex gap-2 items-center opacity-50 w-full sm:w-1/2">
                                            <img src="<?php echo e(asset('ico/phone.png')); ?>" alt="" class="w-4 h-4 object-contain">
                                            <p class="truncate"><?php echo e($specialist->phone); ?></p>
                                        </div>
                                    <?php endif; ?>
                                    <?php if($specialist->email): ?>
                                        <div class="flex gap-2 items-center opacity-50 w-full sm:w-1/2">
                                            <img src="<?php echo e(asset('ico/mail.png')); ?>" alt="" class="w-4 h-4 object-contain">
                                            <p class="truncate"><?php echo e($specialist->email); ?></p>
                                        </div>
                                    <?php endif; ?>
                                    <?php if($specialist->telegram): ?>
                                        <div class="flex gap-2 items-center opacity-50 w-full sm:w-1/2">
                                            <img src="<?php echo e(asset('ico/tg.png')); ?>" alt="" class="w-4 h-4 object-contain">
                                            <p class="truncate"><?php echo e($specialist->telegram); ?></p>
                                        </div>
                                    <?php endif; ?>
                                    <?php if($specialist->vkontacte): ?>
                                        <div class="flex gap-2 items-center opacity-50 w-full sm:w-1/2">
                                            <img src="<?php echo e(asset('ico/vk.png')); ?>" alt="" class="w-4 h-4 object-contain">
                                            <p class="truncate"><?php echo e($specialist->vkontacte); ?></p>
                                        </div>
                                    <?php endif; ?>
                                </a>

                                <!-- Кнопки -->
                                <div class="flex flex-col sm:flex-row gap-2.5 mt-4">
                                    <a href="<?php echo e(route('specialists.show', $specialist->id)); ?>"
                                        class="bg-[#1B1E4A] px-5 py-3 rounded-xl border border-[#0000001a] font-semibold text-[#F5F9FF] text-center whitespace-nowrap">
                                        <?php echo e(number_format($specialist->price, 0, '', ' ')); ?>

                                        ₽/<?php echo e($specialist->getPriceTypeLabel()); ?>

                                    </a>
                                    <form method="post" action="<?php echo e(route('cart.add')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="specialist_id" value="<?php echo e($specialist->id); ?>">
                                        <button
                                            class="bg-[#F5F9FF] cursor-pointer whitespace-nowrap px-5 py-3 rounded-xl border border-[#0000001a] font-semibold text-[#1B1E4A] w-full sm:w-auto">Добавить
                                            в бронь</button>
                                    </form>
                                </div>

                                <?php if($specialist->documents_verified_at): ?>
                                    <div
                                        class="flex items-center gap-2 mt-4 md:absolute md:right-5 md:bottom-5 opacity-50 hover:opacity-100">
                                        <img src="<?php echo e(asset('ico/shild.png')); ?>" alt="" class="w-5 h-5">
                                        <p class="text-[#1B1E4A] text-sm sm:text-base">Исполнитель проверен</p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>


                <?php echo e($specialists->links('vendor.pagination.tailwind')); ?>



                <!-- ./pagitantion -->
            </div>
        </div>
        </div>


        <div class="specialists__text mt-20">
            <!-- title -->
            <div class="pb-10 big-title">
                <h1 class="text-4xl font-semibold">Как выбрать исполнителя?</h1>
                <p class="opacity-50">Вот несколько простых правил, которые помогут выбрать исполнителя </p>
            </div>

            <p>Выбор подходящего исполнителя — ключ к успешному мероприятию. На платформе Party Manager вы найдёте множество
                профессионалов, готовых воплотить ваши идеи в жизнь. Чтобы сделать правильный выбор, рекомендуем обратить
                внимание на несколько важных моментов:</p>

            <div class="flex flex-col gap-5 mt-8 specialists__text__rules mb-36">
                <div class="specialists__text__rule">
                    <h3 class="text-lg font-semibold"> Читайте отзывы</h3>
                    <p>Изучите впечатления других клиентов. Честные отзывы помогут понять, как исполнитель работает,
                        соблюдает ли сроки и насколько клиенты довольны результатом.</p>
                </div>
                <div class="specialists__text__rule">
                    <h3 class="text-lg font-semibold"> Смотрите портфолио</h3>
                    <p>Обязательно посмотрите фотографии или видео работ исполнителя. Так вы оцените стиль, качество
                        исполнения и убедитесь, подходит ли он именно вам.</p>
                </div>
                <div class="specialists__text__rule">
                    <h3 class="text-lg font-semibold">Общайтесь напрямую</h3>
                    <p>Не стесняйтесь задавать вопросы: о стоимости услуг, сроках выполнения, деталях организации. Хороший
                        исполнитель всегда открыт к диалогу и готов обсудить все нюансы.</p>
                </div>
                <div class="specialists__text__rule">
                    <h3 class="text-lg font-semibold">Сравнивайте предложения</h3>
                    <p>На платформе большое количество исполнителей. Вы можете сравнить их условия, цены и предложения. Так
                        вы найдёте лучшее соотношение цены и качества.</p>
                </div>
                <div class="specialists__text__rule">
                    <h3 class="text-lg font-semibold">Обратите внимание на рейтинг</h3>
                    <p>Рейтинг исполнителя показывает его надёжность и профессионализм. Высокий рейтинг — хороший знак, что
                        люди доверяют этому специалисту.</p>
                </div>
                <div class="specialists__text__rule">
                    <h3 class="text-lg font-semibold"> Исполнитель проверен</h3>
                    <p>Если вы видите плажку "Исполнитель проверен", то это означает, что мы проверили исполнения.</p>
                </div>
            </div>
        </div>
    </main>

    <?php echo $__env->make('particals.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <?php $__env->startPush('app-scripts'); ?>
        <script>
            // spec slider
            if (document.querySelector('.specSwiper')) {
                var swiper = new Swiper(".specSwiper", {
                    scrollbar: {
                        el: ".swiper-scrollbar",
                        hide: true,
                    },
                    loop: true,
                    spaceBetween: 20,
                    autoplay: {
                        delay: 5000,
                        disableOnInteraction: false,
                    },
                    simulateTouch: true,
                    keyboard: {
                        enabled: true,
                        onlyInViewport: true,
                    },


                });
            }




            // card slider
            document.querySelectorAll('.card-slider-container').forEach(function (container) {
                var thumbSwiper = new Swiper(container.querySelector('.card-swiper'), {
                    direction: 'horizontal',
                    loop: false,
                    spaceBetween: 5,
                    slidesPerView: 5,
                    freeMode: true,
                    watchSlidesProgress: true,
                });

                var mainSwiper = new Swiper(container.querySelector('.card-swiper2'), {
                    loop: false,
                    spaceBetween: 10,
                    navigation: {
                        nextEl: container.querySelector('.card-swiper-button-next'),
                        prevEl: container.querySelector('.card-swiper-button-prev'),
                    },
                    thumbs: {
                        swiper: thumbSwiper,
                    },

                });

                mainSwiper.on('slideChange', () => {
                    const centerPos = Math.floor(thumbSwiper.params.slidesPerView / 2);
                    const targetThumbIndex = mainSwiper.activeIndex - centerPos;
                    thumbSwiper.slideTo(Math.max(targetThumbIndex, 0));
                });


                const mainEl = container.querySelector('.card-swiper2');
                const realSlidesCount = mainSwiper.slides.length;

                mainEl.addEventListener('mousemove', (e) => {
                    if (realSlidesCount <= 1) return;

                    const rect = mainEl.getBoundingClientRect();
                    let x = e.clientX - rect.left;
                    x = Math.min(Math.max(x, 0), rect.width);
                    const percent = x / rect.width;

                    let targetIndex = Math.floor(percent * realSlidesCount);
                    if (targetIndex >= realSlidesCount) targetIndex = realSlidesCount - 1;

                    mainSwiper.slideTo(targetIndex);
                });


            });



            // range
            if (document.querySelector('#nouislider')) {
                document.querySelectorAll('#nouislider').forEach(slider => {

                    const container = slider.closest('.nouislider-container');
                    const inputFromFormatted = container.querySelector('#priceFromFormatted');
                    const inputToFormatted = container.querySelector('#priceToFormatted');
                    const inputFrom = container.querySelector('#priceFrom');
                    const inputTo = container.querySelector('#priceTo');

                    function formatNumberWithSpaces(num) {
                        return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ");
                    }

                    noUiSlider.create(slider, {
                        start: [<?php echo e($minPrice ? $minPrice : 0); ?>, <?php echo e($maxPrice ? $maxPrice : $globalMax); ?>],
                        connect: true,
                        range: {
                            min: <?php echo e($globalMin); ?>,
                            max: <?php echo e($globalMax); ?>

                                                                                                                                },
                        step: 1,
                        tooltips: [true, true],
                        format: {
                            to: value => Math.round(value),
                            from: value => Number(value)
                        }
                    });

                    slider.noUiSlider.on('update', (values, handle) => {
                        const raw = slider.noUiSlider.get(true)[handle];
                        let cleanValue = handle === 0 ? Math.floor(raw) : Math.ceil(raw);

                        if (handle === 0) {
                            inputFrom.value = cleanValue;
                            inputFromFormatted.value = formatNumberWithSpaces(cleanValue);
                        } else {
                            inputTo.value = cleanValue;
                            inputToFormatted.value = formatNumberWithSpaces(cleanValue);
                        }
                    });

                    function onFormattedInputChange(inputFormatted, inputHidden, min, max, otherValue, isFrom) {
                        let cleanValue = parseInt(inputFormatted.value.replace(/\D/g, '')) || min;
                        if (isFrom) {
                            cleanValue = Math.min(Math.max(cleanValue, min), otherValue - 100);
                        } else {
                            cleanValue = Math.max(Math.min(cleanValue, max), otherValue + 100);
                        }
                        inputHidden.value = cleanValue;
                        inputFormatted.value = formatNumberWithSpaces(cleanValue);
                        if (isFrom) {
                            slider.noUiSlider.set([cleanValue, null]);
                        } else {
                            slider.noUiSlider.set([null, cleanValue]);
                        }
                    }

                    inputFromFormatted.addEventListener('change', () => {
                        onFormattedInputChange(inputFromFormatted, inputFrom, <?php echo e($globalMin); ?>, <?php echo e($globalMax); ?>, slider.noUiSlider.get()[1], true);
                    });

                    inputToFormatted.addEventListener('change', () => {
                        onFormattedInputChange(inputToFormatted, inputTo, <?php echo e($globalMin); ?>, <?php echo e($globalMax); ?>, slider.noUiSlider.get()[0], false);
                    });

                });
            }
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\partymanager-three-withkassa\resources\views\pages\specialists\index.blade.php ENDPATH**/ ?>