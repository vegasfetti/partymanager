<p
    <?php echo e($attributes->class(['fi-global-search-no-results-message px-4 py-4 text-sm text-gray-500 dark:text-gray-400'])); ?>

>
    <?php echo e(__('filament-panels::global-search.no_results_message')); ?>

</p>
<?php /**PATH C:\OSPanel\domains\partymanager-three-withkassa\vendor\filament\filament\resources\views\components\global-search\no-results-message.blade.php ENDPATH**/ ?>