<?php $__env->startSection('title', 'Политика использования файлов cookie | ПАТИМЕНЕДЖЕР'); ?>


<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('particals.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



    <main class="container min-h-[90vh] relative py-4 sm:py-6 lg:py-8">
        <h1 class="font-semibold text-2xl sm:text-4xl">Политика использования файлов cookie</h1>

        <br><br>1. Что такое cookie?

        <br>Cookie — это небольшие текстовые файлы, которые сохраняются на вашем устройстве (компьютере, смартфоне или планшете)
        при посещении сайта. Они помогают сайту запоминать ваши действия и настройки, чтобы улучшить работу с ним.
        <br><br>2. Какие cookie мы используем?

        <br>На сайте применяются следующие типы cookie:

        <br> • Необходимые
        <br>Эти cookie нужны для корректной работы сайта. Без них некоторые функции будут недоступны.

        <br> • Аналитические
        <br>Мы используем сервисы аналитики для сбора анонимной статистики: сколько
        человек посетило сайт, какие страницы просматривали и т.д. Это помогает улучшать наш сервис.

        <br> • Функциональные
        <br>Запоминают ваши предпочтения для удобства использования сайта.

        <br> • Сторонние cookie
        <br>Если на сайте есть кнопки соцсетей или рекламные блоки, эти сервисы могут использовать свои
        cookie. Их политики вы можете посмотреть на официальных сайтах этих компаний.

        <br><br>3. Как управлять cookie?

        <br>Вы можете:

        <br>Отключить cookie в настройках своего браузера.
        Важно: если вы отключите все cookie, некоторые функции сайта перестанут работать.


    </main>


    <?php echo $__env->make('particals.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\partymanager-three-withkassa\resources\views\pages\docs\cookie.blade.php ENDPATH**/ ?>